#pragma once
class genetic_algorithm
{
};

