#pragma once
class Charging_stations
{
};

