#pragma once
#include "Clustering.h"
#include <map>
#include <random>


class Circuit
{
public:
	Circuit(const vector<address_metadata>& centroids);
	~Circuit() ;
	double evaluation(int max_iterations, double tolerance);

	bool check_truck_drone_volume(const truck vehicle, const size_t no_of_drones, size_t& no_of_drone_missing);

	bool check_if_complete(vector<address_metadata>& obj, vector<int>& undelivered_adr_id);

	bool check_drone(vector<drone> drone_list);

	bool check_distance_validity();

	bool check_cluster_validty();

	
	double time = 0;
	double total_energy = 0;
	double total_distance_travelled = 0;
	vector<address_metadata> centroids;
	vector<address_metadata> route;
	size_t route_size = -1;


	template<class T, class T1>
	bool check_for_duplicate_post_codes(vector<T1>& obj);

};

