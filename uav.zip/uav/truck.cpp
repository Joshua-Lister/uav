#include "truck.h"

double truck::return_drone_capacity(){
	return this->drone_capacity;
}

void truck::set_drone_capacity(double dc){
	this->drone_capacity = dc;
}
