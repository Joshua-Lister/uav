#include "Circuit.h"

Circuit::Circuit(const vector<address_metadata>& centroids) : centroids(centroids), route_size(route_size) {
	size_t route_size = centroids.size();
	route.resize(route_size);
};
Circuit::~Circuit() {};


double Circuit::evaluation(int max_iterations, double tolerance) {
	for (size_t iter_num = 0; iter_num < max_iterations; iter_num++) {

	}
}

void Circuit::crossover(Circuit& Circuit2, Circuit& child1, Circuit& child2, default_random_engine& generator) {
	uniform_int_distribution<int> dis1(1, route_size - 1);
	int random_position_1 = dis1(generator);
	uniform_int_distribution<int> dis2(random_position_1, route_size - 1);
	int random_position_2 = dis2(generator);

	for (size_t i = 0; i < route_size; i++) {
		if (i < random_position_2) {
			child1.route[i] = 
		}
	}
}
bool Circuit::check_truck_drone_volume(const truck vehicle, const size_t no_of_drones, size_t& no_of_drone_missing) {
	if (vehicle.drone_capacity == no_of_drones)
		return true;
	no_of_drone_missing = vehicle.drone_capacity - no_of_drones;
	return false;
}
bool Circuit::check_if_complete(vector<address_metadata>& obj, vector<int>& undelivered_adr_id){
	for (auto const& adr : obj) {
		if (adr.visited == false) 
			undelivered_adr_id.push_back(adr.id);
	}
	if (undelivered_adr_id.size() == 0)
				return false;
	return true;
}
bool Circuit::check_drone(vector<drone> drone_list) {

	for (auto& drone : drone_list)
		if (drone.battery_energy == 0) {
			if (drone.battery_swap == false)
				drone.out_of_use = true;
		}
		else {
			auto x = drone::return_battery_energy_capacity;
			//drone.battery_energy = drone::return_battery_energy_capacity;
		}
		
}


template <class T, class T1>
bool Circuit::check_for_duplicate_post_codes(vector<T1>& obj) {
	map<T, int> duplicate_post_codes;
	for (const auto& adr : obj) {
		auto post_code = duplicate_post_codes.insert(pair<T int>(adr.post_code, 1));
		if (post_code.second == false)
			post_code.first->second++;
	}
	for (const auto& post_code : duplicate_post_codes) {
		if (post_code->second == 1)
			post_code = duplicate_post_codes.erase(post_code);
		else
			post_code++;
	}
}