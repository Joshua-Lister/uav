#include "genetic_algorithm.h"

int selection(std::vector<double>& fitness_v, int generation_size, double fitness_total, std::default_random_engine& generator)
{
    double random_number = randnum(generator);
    double offset = 0;

    for (int i = 0; i < generation_size; i++)
    {
        offset += fitness_v[i] / fitness_total;
        // subtract small number to avoid getting stuck in environments with no variation
        if (random_number < (offset - 1e-3))
            return i;
    }
    // only used when stuck in environments with no variation
    std::uniform_int_distribution<int> randgen(0, generation_size - 1);
    return randgen(generator);
}

Genetic_Algorithm(int num_units, int generation_size, double crossover_prob, double mutation_prob,
    int max_generation, double tolerance, int max_iterations, unsigned seed)
{
    std::default_random_engine generator(seed);
    std::uniform_int_distribution<int> randgen(0, generation_size - 1);

    // Vector to contain fitness values
    std::vector<double> fitness_v(generation_size);
    std::vector<double> performance_v;

    int gen = 0;
    while (gen <= max_generation)
    {
    }

    auto max_it = std::max_element(fitness_v.begin(), fitness_v.end());
    double max = *max_it;
    double min = *(std::min_element(fitness_v.begin(), fitness_v.end()));

    int elite_ind = std::distance(fitness_v.begin(), max_it);
    
    if (std::abs(max - prev_max) < tolerance)
        conv_cnt++;
    else
        conv_cnt = 0;
    prev_max = max;
